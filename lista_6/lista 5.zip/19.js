let fita_rna = "ACTAGCCATCGA"
let complementar;

 complementar = fita_rna.replace(/T/g, "U")

console.log(complementar.split("").join(""))
