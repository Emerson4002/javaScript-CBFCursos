let sequencia = number(prompt("Digite a sequencia"))
//não fanalizei
switch(sequencia){
    case 0:
        console.log("D")
        break;
    case 1:
        console.log("E")
        break;
    
}