//Um n umero par  ́e um n ́umero inteiro que pode ser escrito na forma 2n e n  ́e inteiro. Escreva
// um algoritmo que imprima os 200 primeiros n ́umeros pares, iniciando do 2.
for(let i = 2; i <= 404; i++)
{
    if(i%2 == 0)
    {
        console.log(i)

    }
}