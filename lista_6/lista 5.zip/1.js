for(let i=0; i<=50;i++){
    console.log("Eu gosto de algoritmos");
}