// Escreva um algoritmo que leia uma palavra e indique o n ́umero de ocorrˆencias da letra A.
let palavra = (prompt("Digite uma palavra")).toUpperCase();

console.log(palavra.indexOf("A"))