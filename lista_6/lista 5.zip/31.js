// Escreva um algoritmo que leia duas strings e encontre a maior substring comum entre elas.
// Como sa ́ıda deve imprimir o tamanho desta maior substring.

let num; 
let num2; 
let multi = 0;

while(num != 0 && num2 !=0){
   num = Number(prompt("Digite um valor"))
   num2 = Number(prompt("Digite um valor"))
   multi = num2 * num;
   console.log(multi)
  
}