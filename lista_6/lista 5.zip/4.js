//Escreva um algoritmo que imprima a raiz quadrada dos n ́umeros de 50 a 100.

for(let i = 50; i <=100; i++)
{
   let raiz = Math.sqrt(i); 
    console.log(raiz)

}