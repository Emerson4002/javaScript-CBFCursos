//Escreva um algoritmo que imprima na tela os n ́umero de 300 a 201.

for(let i=300; i>=201; i--)
{
    console.log(i)

}