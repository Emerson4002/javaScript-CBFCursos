//2. Escreva um algoritmo que imprima na tela os n ́umero de 101 a 200.

for(let i=101; i<=200; i++)
{
    console.log(i)

}